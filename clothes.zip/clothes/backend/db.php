<?php

$host = "localhost";
$user = "id20880347_haiat32";
$pass = "Abood7777$$";
$database = "id20880347_haiat11";

$con = new mysqli($host,$user,$pass,$database);


?>